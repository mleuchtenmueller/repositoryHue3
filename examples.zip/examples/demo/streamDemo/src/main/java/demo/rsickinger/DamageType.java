package demo.rsickinger;

public enum DamageType {
    SLASHING, PIERCING, BLUNT, MISSILE, NONE
}
