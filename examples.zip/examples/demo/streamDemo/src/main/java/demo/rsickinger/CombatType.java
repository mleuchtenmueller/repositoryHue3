package demo.rsickinger;

public enum CombatType {
    MELEE, RANGED, NONE
}
