public class Mensch implements Student{
    public void doThings() {

    }
}
