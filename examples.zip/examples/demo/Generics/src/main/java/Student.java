public interface Student {
    public void doThings();
}
